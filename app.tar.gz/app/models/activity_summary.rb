class ActivitySummary < ActiveRecord::Base
self.view_name = 'ActivitySummary'
def readonly?
 true
 end
def self.refresh_view
 connection = ActiveRecord::Base.connection
 connection.execute(‘REFRESH MATERIALIZED VIEW CONCURRENTLY ActivitySummary’)
 end

  def self.to_csv(options = {})
    CSV.generate(options) do |csv|
      csv << column_names
      all.each do |p|
        csv << p.attributes.values_at(*column_names)
      end
    end
  end
end
