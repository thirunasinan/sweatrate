class Units < ActiveRecord::Base
	self.table_name= "units"

end